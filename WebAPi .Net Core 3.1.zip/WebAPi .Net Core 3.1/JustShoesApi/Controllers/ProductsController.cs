﻿using JustShoesApi.EF;
using JustShoesApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private justshoesContext _db;

        public ProductsController(justshoesContext db)
        {
            _db = db;
        }

        [Route("GetAll")]
        [HttpGet]
        public IActionResult GetAll()
        {
            var products = _db.Products.ToList();
            if (products is null)
            {
                return BadRequest("No Products Found");
            }
            else
            {
                return Ok(products);
            }
        }

        [Route("Get/{id}")]
        [HttpGet]
        public IActionResult Get(int id)
        {
            var products = _db.Products.Find(id);
            if (products is null)
            {
                return BadRequest("No Product Found");
            }
            else
            {
                return Ok(products);
            }
        }

        [Route("Create")]
        [HttpPost]
        public IActionResult Create(ProductsModel productsModel)
        {
            if (string.IsNullOrEmpty(productsModel.ProductName))
                return BadRequest("No Product Name Entered");

            Products products = new Products();
            products.ProductName = productsModel.ProductName;
            products.ProductPrice = productsModel.ProductPrice;
            products.ProductQuantity = productsModel.ProductQuantity;
            products.ProductImage = productsModel.ProductImage;
            products.ProductImageName = productsModel.ProductImageName;
            products.ProductImageType = productsModel.ProductImageType;

            _db.Products.Add(products);
            _db.SaveChanges();

            return Ok(products);

        }

        [Route("Update")]
        [HttpPut]
        public IActionResult Update(ProductsModel productsModel)
        {
            if (productsModel.id == 0)
                return BadRequest("No id Entered");

            if (string.IsNullOrEmpty(productsModel.ProductName))
                return BadRequest("No Product Name Entered");

            var products = _db.Products.Find(productsModel.id);

            if (products is null)
            {
                return BadRequest("No id Found");
            }
            else
            {

                products.ProductName = productsModel.ProductName;
                products.ProductPrice = productsModel.ProductPrice;
                products.ProductQuantity = productsModel.ProductQuantity;
                products.ProductImage = productsModel.ProductImage;
                products.ProductImageName = productsModel.ProductImageName;
                products.ProductImageType = productsModel.ProductImageType;

                _db.Products.Attach(products);
                _db.SaveChanges();

                return Ok(products);
            }
        }

        [Route("Delete/{id}")]
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var products = _db.Products.Find(id);
            if (products is null)
            {
                return BadRequest("No Data Found");
            }
            else
            {
                _db.Products.Remove(products);
                _db.SaveChanges();
                return Ok(products);
            }
        }
    }
}
