﻿using JustShoesApi.EF;
using JustShoesApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private justshoesContext _db;

        public CartController(justshoesContext db)
        {
            _db = db;
        }

        [Route("Get/{Email}")]
        [HttpGet]
        public IActionResult Get(string Email)
        {
            var Cart = _db.Cart.Where(e => e.UserEmail.ToLower() == Email).ToList();
            if (Cart.Count == 0)
            {
                return BadRequest("No User Found");
            }
            else
            {
                return Ok(Cart);
            }
        }


        [Route("Create")]
        [HttpPost]
        public IActionResult Create(CartModel cartModel)
        {
            if (string.IsNullOrEmpty(cartModel.UserEmail))
                return BadRequest("No Cart found");

            Cart cart = new Cart();
            cart.ProductId = cartModel.ProductId;
            cart.ProductName = cartModel.ProductName;
            cart.ProductQuantity = cartModel.ProductQuantity;
            cart.ProductPrice = cartModel.ProductPrice;
            cart.UserEmail = cartModel.UserEmail;

            _db.Cart.Add(cart);
            _db.SaveChanges();

            return Ok(cart);
        }

        [Route("Delete/{id}")]
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var cart = _db.Cart.Find(id);
            if (cart is null)
            {
                return BadRequest("No Data Found");
            }
            else
            {
                _db.Cart.Remove(cart);
                _db.SaveChanges();
                return Ok(cart);
            }
        }



    }
}
