﻿using JustShoesApi.EF;
using JustShoesApi.Models;
using JustShoesApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {

        private justshoesContext _db;
        private readonly IMailService _mailService;

        public UsersController(justshoesContext db, IMailService mailService)
        {
            _db = db;
            _mailService = mailService;
        }

        [Route("GetAll")]
        [HttpGet]
        public IActionResult GetAll()
        {
            var users = _db.Users.ToList();
            return Ok(users);
        }


        [Route("Check/{Email}")]
        [HttpGet]
        public IActionResult Get(string Email)
        {
            //Check if email is exists in DB
            var user = _db.Users.Where(e => e.EmailAddress.ToLower() == Email).ToList();
            if (user.Count == 0)
            {
                return BadRequest("No User Found");
            }
            else
            {
                return Ok(user);
            }
        }

        [Route("CheckSignin/{Email}/{Password}")]
        [HttpGet]
        public IActionResult Get(string Email, string Password)
        {
            //Check if email is exists in DB
            var user = _db.Users.Where(e => e.EmailAddress.ToLower() == Email && e.Password.ToLower() == Password).ToList();
            if (user.Count == 0)
            {
                return BadRequest("Incorrect Email or Password!");
            }
            else
            {
                return Ok(user);
            }
        }

        [Route("Create")]
        [HttpPost]
        public IActionResult Create(UsersModel usersModel)
        {
            if (string.IsNullOrEmpty(usersModel.EmailAddress))
                return BadRequest("No Email Address Entered");

            Users user = new Users();
            user.EmailAddress = usersModel.EmailAddress;
            user.Password = usersModel.Password;
            user.Active = usersModel.Active;

            _db.Users.Add(user);
            _db.SaveChanges();

            //string url = "https://localhost:44321/api/Users/Activate/";

            MailReq mailReq = new MailReq();
            mailReq.ToAddresses = user.EmailAddress;
            mailReq.Subject = "Welcome to JustShoes";
            mailReq.Body = "Dear " + user.EmailAddress + "<br/>" +
                "This is a email confirming your Registration with <b> Email address </b> :" + user.EmailAddress + " and <b> Password </b> :" + user.Password + ". <h4> Happy Shopping :) </h4> .";
            _mailService.Send(mailReq);
            return Ok(user);
        }


        [Route("Activate/{EmailAddress}")]
        [HttpPut]
        public IActionResult Update(string EmailAddress)
        {

            var user = _db.Users.Where(e => e.EmailAddress.ToLower() == EmailAddress).ToList();
            if (user.Count == 0)
            {
                return BadRequest("No User Found");
            }
            else
            {
                var data = user.FirstOrDefault(e => e.EmailAddress == EmailAddress);
                data.Active = 1;
                _db.Users.Update(data);
                _db.SaveChanges();
                return Ok(user);
            }
        }


        [Route("Update")]
        [HttpPut]
        public IActionResult Update(UsersModel usersModel)
        {
            if (usersModel.Id == 0)
                return BadRequest("No id Entered");

            if (string.IsNullOrEmpty(usersModel.EmailAddress))
                return BadRequest("No Email Address Entered");

            var users = _db.Users.Find(usersModel.Id);

            if (users is null)
            {
                return BadRequest("No id Found");
            }
            else
            {

                users.EmailAddress = usersModel.EmailAddress;
                users.Password = usersModel.Password;
                users.Active = usersModel.Active;

                _db.Users.Attach(users);
                _db.SaveChanges();

                return Ok(users);
            }
        }

        [Route("Delete/{id}")]
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var users = _db.Users.Find(id);
            if (users is null)
            {
                return BadRequest("No Data Found");
            }
            else
            {
                _db.Users.Remove(users);
                _db.SaveChanges();
                return Ok(users);
            }
        }

    }
}