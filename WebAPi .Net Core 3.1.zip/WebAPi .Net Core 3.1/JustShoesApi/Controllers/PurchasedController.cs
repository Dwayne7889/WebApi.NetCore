﻿using JustShoesApi.EF;
using JustShoesApi.Models;
using JustShoesApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchasedController : ControllerBase
    {

        private justshoesContext _db;
        private readonly IMailService _mailService;

        public PurchasedController(justshoesContext db, IMailService mailService)
        {
            _db = db;
            _mailService = mailService;
        }


        [Route("Create")]
        [HttpPost]
        public IActionResult Create(PurchasedModel purchasedModel)
        {
            if (string.IsNullOrEmpty(purchasedModel.UserEmail))
                return BadRequest("No UserEmail Found");
           string OrderNumber = "#JS" + DateTime.Now.Ticks.ToString().Remove(5);

            var Cart = _db.Cart.Where(e => e.UserEmail.ToLower() == purchasedModel.UserEmail).ToList();
            for (int i = 0; Cart.Count > i; ++i)
            {
                Purchased purchased = new Purchased();
                purchased.UserEmail = purchasedModel.UserEmail;
                purchased.ProductTotal = purchasedModel.ProductTotal;
                purchased.DatePurchased = DateTime.Now.ToString("dd/MM/yyyy");
                purchased.OrderNumber = OrderNumber;


                purchased.ProductId = Cart[i].ProductId;
                purchased.ProductName = Cart[i].ProductName;
                purchased.ProductQuantity = Cart[i].ProductQuantity;
                purchased.ProductPrice = Cart[i].ProductPrice;
                _db.Purchased.Add(purchased);    
                _db.SaveChanges();
            }

            MailReq mailReq = new MailReq();
            mailReq.ToAddresses = purchasedModel.UserEmail;
            mailReq.Subject = "JustShoes CheckoutList";
            string products = "<table>" +
                " <tr><th> Product Name </th><th> Product Quantity </th>" +
                " <tr><th> Product Price </th></tr> ";

            for (int i = 0; Cart.Count > i; ++i)
            {
                products += "<tr>";
                products += "<td>" + Cart[i].ProductName + "</td>";
                products += "<td>" + Cart[i].ProductQuantity + "</td>";
                products += "<td> R " + Cart[i].ProductPrice + "</td>";
                products += "</tr>";
            }

            products += "<tr><td></td><td>Total</td><td><h4>R" + purchasedModel.ProductTotal + "</h4></td></tr></table>";



            mailReq.Body = "Dear " + purchasedModel.UserEmail + "<br/>" +
                "Date: " + DateTime.Now.ToString("dd/MM/yyyy") + " <b> OrderNumber </b> :" + OrderNumber + ". <br/> "
                + products;
            _mailService.Send(mailReq);
            return Ok();
     
            
        }
    }
}
