﻿using System;
using System.Collections.Generic;

namespace JustShoesApi.EF
{
    public partial class Cart
    {
        public int Id { get; set; }
        public string UserEmail { get; set; }
        public int? ProductId { get; set; }
        public string ProductName { get; set; }
        public int? ProductQuantity { get; set; }
        public int? ProductPrice { get; set; }
    }
}
