﻿using System;
using System.Collections.Generic;

namespace JustShoesApi.EF
{
    public partial class Users
    {
        public int Id { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
        public int? Active { get; set; }
    }
}
