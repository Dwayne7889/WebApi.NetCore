﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Models
{
    public class CartModel
    {
        [JsonProperty("CartID")]
        public int id { get; set; }

        [JsonProperty("Cart")]

        public string UserEmail { get; set; }
        public int? ProductId { get; set; }
        public string ProductName { get; set; }
        public int? ProductQuantity { get; set; }
        public int? ProductPrice { get; set; }
    }
}
