﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Models
{
    public class ProductsModel
    {
        [JsonProperty("ProductID")]
        public int id { get; set; }

        [JsonProperty("Products")]
        public string ProductName { get; set; }
        public int? ProductQuantity { get; set; }
        public string ProductPrice { get; set; }
        public string ProductImage { get; set; }
        public string ProductImageName { get; set; }
        public string ProductImageType { get; set; }

    }
}
