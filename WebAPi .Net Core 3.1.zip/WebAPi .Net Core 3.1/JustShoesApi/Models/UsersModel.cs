﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Models
{
    public class UsersModel
    {
        [JsonProperty("UserId")]
        public int Id { get; set; }

        [JsonProperty("Users")]
  
        public string EmailAddress { get; set; }
        public string Password { get; set; }
        public int? Active { get; set; }
    }
}
