﻿using JustShoesApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Services
{
   public interface IMailService
    {
        void Send(MailReq emailMessage);
        List<MailReq> ReceiveEmail(int maxCount = 4);
    }
}
