﻿using JustShoesApi.Models;
using MailKit.Net.Smtp;
using MimeKit;
using MimeKit.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustShoesApi.Services
{
    public class MailService : IMailService
    {
        private readonly IMailConfig _emailConfiguration;

        public MailService(IMailConfig emailConfiguration)
        {
            _emailConfiguration = emailConfiguration;
        }

        public void Send(MailReq emailMessage)
        {
			var message = new MimeMessage();
			message.To.Add(new MailboxAddress(emailMessage.ToAddresses, emailMessage.ToAddresses));
			message.From.Add(new MailboxAddress(_emailConfiguration.SmtpUsername, _emailConfiguration.SmtpUsername));

			message.Subject = emailMessage.Subject;
			//We will say we are sending HTML. But there are options for plaintext etc. 
			message.Body = new TextPart(TextFormat.Html)
			{
				Text = emailMessage.Body
			};

			//Be careful that the SmtpClient class is the one from Mailkit not the framework!
			using (var emailClient = new SmtpClient())
			{
				//The last parameter here is to use SSL
				emailClient.Connect(_emailConfiguration.SmtpServer, _emailConfiguration.SmtpPort,false);

				//Remove any OAuth functionality as we won't be using it. 
				emailClient.AuthenticationMechanisms.Remove("XOAUTH2");

				emailClient.Authenticate(_emailConfiguration.SmtpUsername, _emailConfiguration.SmtpPassword);

				emailClient.Send(message);

				emailClient.Disconnect(true);
			}
			}

        List<MailReq> IMailService.ReceiveEmail(int maxCount)
        {
            throw new NotImplementedException();
        }
    }
}
