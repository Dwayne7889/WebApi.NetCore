In 'appsettings.json',' ConnectionStrings', 'JustShoes' change Server={Your Server};UID={Your username};PASSWORD={Your Password};SslMode={Depends on your settings};


